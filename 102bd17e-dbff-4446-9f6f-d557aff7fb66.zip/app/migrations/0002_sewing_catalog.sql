CREATE TABLE IF NOT EXISTS machines (id INTEGER PRIMARY KEY AUTOINCREMENT, brand TEXT NOT NULL, category TEXT NOT NULL, model TEXT NOT NULL, price TEXT NOT NULL, description TEXT DEFAULT '', image_url TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT NOT NULL UNIQUE, consent_accepted INTEGER NOT NULL DEFAULT 0, consent_version TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, is_admin INTEGER NOT NULL DEFAULT 0, expires_at TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')), FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS bookings (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, machine_id INTEGER, machine_model TEXT NOT NULL, customer_name TEXT NOT NULL, phone TEXT NOT NULL, note TEXT DEFAULT '', preferred_date TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now')), FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_machines_brand ON machines(brand);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
INSERT OR IGNORE INTO machines (id,brand,category,model,price,description) VALUES
(1,'VIDYA','Domestic','Tailor Model','Ask dealer','Reliable domestic tailoring machine.'),
(2,'VIDYA','Domestic','Link Model','Ask dealer','Domestic sewing machine.'),
(3,'VIDYA','Domestic','Deluxe Model','Ask dealer','Domestic tailoring machine.'),
(4,'VIDYA','Domestic','Over Lock','Ask dealer','Overlock finishing machine.'),
(5,'VIDYA','Domestic','130K Zig-Zag','₹4,200*','Zig-zag sewing machine.'),
(6,'VIDYA','Automatic Zig-Zag','Sew & Go-1','₹6,500*','Automatic zig-zag model.'),
(7,'VIDYA','Automatic Zig-Zag','Sew & Go-3','₹7,500*','Automatic zig-zag model.'),
(8,'VIDYA','Automatic Zig-Zag','B-33','₹5,500*','Automatic zig-zag model.'),
(9,'VIDYA','Automatic Zig-Zag','B-35','₹5,500*','Automatic zig-zag model.'),
(10,'VIDYA','Embroidery','FW-920','Ask dealer','Embroidery machine.'),
(11,'VIDYA','Embroidery','FW-1201','Ask dealer','Embroidery machine.'),
(12,'JACK','Lockstitch','F6 Basic','₹23,500–₹26,000','Industrial lockstitch machine.'),
(13,'JACK','Lockstitch','A2C Auto Thread Trimmer','₹26,000–₹29,000','Automatic thread trimming.'),
(14,'JACK','Lockstitch','A3C / A3C-C','₹29,800–₹33,000','Computerized industrial lockstitch.'),
(15,'JACK','Lockstitch','A4C Digital','₹35,000–₹37,500','Digital industrial lockstitch.'),
(16,'JACK','Lockstitch','A5E-B AMH2 AI','₹45,000–₹49,500','Advanced industrial machine.'),
(17,'JACK','Overlock','E4S','₹32,500–₹38,799','Industrial overlock.'),
(18,'JACK','Overlock','C4 Fully Automatic','₹43,300–₹45,500','Automatic overlock.'),
(19,'JACK','Overlock','C7 URUS AI','₹58,000*','Advanced overlock.'),
(20,'JACK','Heavy Duty','H2 Basic Top Feed','₹34,000*','Heavy-duty top-feed machine.'),
(21,'JACK','Heavy Duty','H7 Digital Top Feed','₹45,000*','Digital heavy-duty top-feed machine.'),
(22,'JACK','Zig-Zag','20U 9 mm Short Arm','₹35,500*','Industrial zig-zag machine.'),
(23,'JACK','Zig-Zag','2290 8 mm Digital','₹50,000*','Digital zig-zag machine.'),
(24,'JACK','Special','T1900 GHD/GSD Bartacking','₹1,28,500*','Electronic bartacking machine.'),
(25,'JACK','Special','1790G Electronic Buttonhole','₹1,95,000*','Electronic buttonhole machine.');
